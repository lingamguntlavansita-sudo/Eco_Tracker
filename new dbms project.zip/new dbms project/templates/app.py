from flask import Flask, render_template, request, redirect, url_for, session
import mysql.connector

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Required for session management

# Configure your MySQL database connection
def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",          # Replace with your MySQL username if different
        password="root",      # Replace with your MySQL password
        database="eco_tracker"# Matches your database name
    )

# --- PAGE RENDERING ROUTES ---

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.html')

@app.route('/carbon')
def carbon():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('carbon.html')

@app.route('/electricity')
def electricity():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('electricity.html')

@app.route('/water')
def water():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('water.html')

@app.route('/waste')
def waste():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('waste.html')


# --- AUTHENTICATION ROUTES ---

@app.route('/login', methods=['GET', 'POST'])
def login():
    error_message = None
    if request.method == 'POST':
        email = request.form.get('email')         
        password = request.form.get('password')   
        
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE Email = %s AND Password = %s", (email, password))
        user = cursor.fetchone()
        cursor.close()
        conn.close()
        
        if user:
            # Store User_ID and Name in session
            session['user_id'] = user['User_ID']
            session['user_name'] = user['Name']
            return redirect(url_for('dashboard'))
        else:
            error_message = "Invalid email or password. Please try again."
            
    return render_template('login.html', error=error_message)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name')           
        email = request.form.get('email')         
        phone = request.form.get('phone')         
        location = request.form.get('location')   
        password = request.form.get('password')   
        
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(
                "INSERT INTO users (Name, Phone, Email, Password, Location) VALUES (%s, %s, %s, %s, %s)",
                (name, phone, email, password, location)
            )
            conn.commit()
        except Exception as e:
            print(f"Error registering user: {e}")
        finally:
            cursor.close()
            conn.close()
        
        return redirect(url_for('login'))
        
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))


# --- TRACKING FORM SUBMISSION & CALCULATION ROUTES ---

@app.route('/add_carbon', methods=['POST'])
def add_carbon():
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    if request.method == 'POST':
        user_id = session['user_id']
        transport_type = request.form.get('transport_type')
        distance_travelled = float(request.form.get('distance_travelled') or 0)
        
        electricity_units = float(request.form.get('electricity_units') or 0)
        lpg_usage = float(request.form.get('lpg_usage') or 0)
        food_type = request.form.get('food_type')
        record_date = request.form.get('record_date')
        
        # --- AUTOMATIC EMISSION CALCULATIONS ---
        # 1. Transport emissions (kg CO2 per km estimates)
        transport_factors = {'car': 0.21, 'bike': 0.08, 'bus': 0.05, 'train': 0.04, 'flight': 0.25}
        t_factor = transport_factors.get(str(transport_type).lower(), 0.20)
        transport_emission = distance_travelled * t_factor
        
        # 2. Electricity emissions (approx 0.85 kg per unit)
        electricity_emission = electricity_units * 0.85
        
        # 3. LPG emissions (approx 2.98 kg per unit/kg)
        lpg_emission = lpg_usage * 2.98
        
        # 4. Food emissions based on food type
        food_factors = {'meat': 3.3, 'vegetarian': 1.5, 'vegan': 1.0, 'mixed': 2.2}
        f_factor = food_factors.get(str(food_type).lower(), 2.0)
        food_emission = f_factor * 1.0  # standard base multiplier
        
        # 5. Total Combined Emission
        total_emission = transport_emission + electricity_emission + lpg_emission + food_emission
        
        # Save to MySQL carbon_record table matching exact columns
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            """INSERT INTO carbon_record 
            (User_ID, Transport_Type, Distance_Traveled, Transport_Emission, Electricity_Units, Electricity_Emission, LPG_Usage, LPG_Emission, Food_Type, Food_Emission, Total_Emission, Record_Date) 
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
            (user_id, transport_type, distance_travelled, transport_emission, electricity_units, electricity_emission, lpg_usage, lpg_emission, food_type, food_emission, total_emission, record_date)
        )
        conn.commit()
        cursor.close()
        conn.close()
        
        return redirect(url_for('dashboard'))

@app.route('/add_electricity', methods=['POST'])
def add_electricity():
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    if request.method == 'POST':
        user_id = session['user_id']
        appliance_name = request.form.get('appliance_name')
        usage_hours = float(request.form.get('usage_hours') or 0)
        units_consumed = float(request.form.get('units_consumed') or 0)
        record_date = request.form.get('record_date')
        
        # Calculate carbon emission from electricity usage
        carbon_emission = units_consumed * 0.85
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            """INSERT INTO electricity_usage 
            (User_ID, Appliance_Name, Usage_Hours, Units_Consumed, Carbon_Emission, Record_Date) 
            VALUES (%s, %s, %s, %s, %s, %s)""",
            (user_id, appliance_name, usage_hours, units_consumed, carbon_emission, record_date)
        )
        conn.commit()
        cursor.close()
        conn.close()
        
        return redirect(url_for('dashboard'))

@app.route('/add_water', methods=['POST'])
def add_water():
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    if request.method == 'POST':
        user_id = session['user_id']
        activity_type = request.form.get('activity_type')
        water_consumed = float(request.form.get('water_consumed') or 0)
        record_date = request.form.get('record_date')
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            """INSERT INTO water_usage 
            (User_ID, Activity_Type, Water_Consumed, Record_Date) 
            VALUES (%s, %s, %s, %s)""",
            (user_id, activity_type, water_consumed, record_date)
        )
        conn.commit()
        cursor.close()
        conn.close()
        
        return redirect(url_for('dashboard'))

@app.route('/add_waste', methods=['POST'])
def add_waste():
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    if request.method == 'POST':
        user_id = session['user_id']
        waste_type = request.form.get('waste_type')
        quantity = float(request.form.get('quantity') or 0)
        recycled_quantity = float(request.form.get('recycled_quantity') or 0)
        disposal_method = request.form.get('disposal_method')
        record_date = request.form.get('record_date')
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            """INSERT INTO waste_record 
            (User_ID, Waste_Type, Quantity, Recycled_Quantity, Disposal_Method, Record_Date) 
            VALUES (%s, %s, %s, %s, %s, %s)""",
            (user_id, waste_type, quantity, recycled_quantity, disposal_method, record_date)
        )
        conn.commit()
        cursor.close()
        conn.close()
        
        return redirect(url_for('dashboard'))


if __name__ == '__main__':
    app.run(debug=True)