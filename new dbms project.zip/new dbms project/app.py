from flask import Flask, render_template, request, redirect, url_for, session
import mysql.connector

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Required for session management


# Configure your MySQL database connection
def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",          # Replace with your MySQL username if different
        password="root",      # Replace with your MySQL password
        database="eco_tracker"# Matches your database name
    )


# --- PAGE RENDERING ROUTES ---

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    # Prevent admins from accessing the user dashboard view
    if session.get('role') in ['Admin', 'Developer']:
        return redirect(url_for('admin_dashboard'))
        
    user_id = session['user_id']
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    # 1. TODAY'S METRICS (Filtered by CURDATE() for day-to-day tracking)
    cursor.execute("SELECT IFNULL(SUM(Total_Emission), 0) AS total FROM carbon_record WHERE User_ID = %s AND Record_Date = CURDATE()", (user_id,))
    total_carbon = round(float(cursor.fetchone()['total']), 1)

    cursor.execute("SELECT IFNULL(SUM(Units_Consumed), 0) AS total FROM electricity_usage WHERE User_ID = %s AND Record_Date = CURDATE()", (user_id,))
    total_electricity = round(float(cursor.fetchone()['total']), 1)

    cursor.execute("SELECT IFNULL(SUM(Water_Consumed), 0) AS total FROM water_usage WHERE User_ID = %s AND Record_Date = CURDATE()", (user_id,))
    total_water = round(float(cursor.fetchone()['total']), 1)

    cursor.execute("SELECT IFNULL(SUM(Quantity), 0) AS total FROM waste_record WHERE User_ID = %s AND Record_Date = CURDATE()", (user_id,))
    total_waste = round(float(cursor.fetchone()['total']), 1)

    # 2. Balanced Daily Eco Score Calculation (Scaled down for realistic impact)
    deductions = (total_carbon * 0.005) + (total_electricity * 0.05) + (total_water * 0.002) + (total_waste * 0.1)
    eco_score = max(10, min(100, int(100 - deductions)))

    # --- 3. AUTOMATED 7-DAY & MONTHLY SCORE PERSISTENCE ---
    
    # Calculate 7-day rolling average score
    cursor.execute("""
        SELECT AVG(daily_score) as avg_7day FROM (
            SELECT Record_Date, 
                   GREATEST(10, LEAST(100, 100 - (
                       IFNULL(SUM(Total_Emission),0)*0.005 + 10
                   ))) as daily_score
            FROM carbon_record 
            WHERE User_ID = %s AND Record_Date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
            GROUP BY Record_Date
        ) as recent_days
    """, (user_id,))
    weekly_res = cursor.fetchone()
    avg_7day_score = round(float(weekly_res['avg_7day'] or eco_score), 1)

    # Save to weekly_eco_scores if not already logged for today
    cursor.execute("""
        SELECT * FROM weekly_eco_scores 
        WHERE User_ID = %s AND Week_End = CURDATE()
    """, (user_id,))
    if not cursor.fetchone():
        try:
            cursor.execute("""
                INSERT INTO weekly_eco_scores (User_ID, Week_Start, Week_End, Avg_Score)
                VALUES (%s, DATE_SUB(CURDATE(), INTERVAL 7 DAY), CURDATE(), %s)
            """, (user_id, avg_7day_score))
            conn.commit()
        except Exception as e:
            print(f"Weekly score logging error: {e}")

    # Calculate and save monthly average score
    cursor.execute("SELECT DATE_FORMAT(CURDATE(), '%M %Y') as m_name")
    current_month_str = cursor.fetchone()['m_name']

    cursor.execute("""
        SELECT AVG(daily_score) as avg_month FROM (
            SELECT Record_Date, 
                   GREATEST(10, LEAST(100, 100 - (
                       IFNULL(SUM(Total_Emission),0)*0.005 + 10
                   ))) as daily_score
            FROM carbon_record 
            WHERE User_ID = %s AND MONTH(Record_Date) = MONTH(CURDATE()) AND YEAR(Record_Date) = YEAR(CURDATE())
            GROUP BY Record_Date
        ) as month_days
    """, (user_id,))
    month_res = cursor.fetchone()
    avg_monthly_score = round(float(month_res['avg_month'] or eco_score), 1)

    cursor.execute("""
        SELECT * FROM monthly_eco_scores 
        WHERE User_ID = %s AND Month_Year = %s
    """, (user_id, current_month_str))
    if not cursor.fetchone():
        try:
            cursor.execute("""
                INSERT INTO monthly_eco_scores (User_ID, Month_Year, Avg_Score)
                VALUES (%s, %s, %s)
            """, (user_id, current_month_str, avg_monthly_score))
            conn.commit()
        except Exception as e:
            print(f"Monthly score logging error: {e}")

    # Fetch saved weekly and monthly history for review/display
    cursor.execute("SELECT * FROM weekly_eco_scores WHERE User_ID = %s ORDER BY Week_End DESC LIMIT 4", (user_id,))
    saved_weekly_scores = cursor.fetchall()

    cursor.execute("SELECT * FROM monthly_eco_scores WHERE User_ID = %s ORDER BY Score_ID DESC LIMIT 6", (user_id,))
    saved_monthly_scores = cursor.fetchall()

    # --- END OF PERSISTENCE LOGIC ---

    # 4. Daily Activity Overview Chart Data (Grouped by Date)
    cursor.execute("""
        SELECT DATE_FORMAT(Record_Date, '%d %b') as activity_date, SUM(val) as daily_total FROM (
            SELECT Record_Date, Total_Emission as val FROM carbon_record WHERE User_ID = %s
            UNION ALL
            SELECT Record_Date, Units_Consumed as val FROM electricity_usage WHERE User_ID = %s
            UNION ALL
            SELECT Record_Date, Water_Consumed as val FROM water_usage WHERE User_ID = %s
            UNION ALL
            SELECT Record_Date, Quantity as val FROM waste_record WHERE User_ID = %s
        ) as combined
        WHERE Record_Date IS NOT NULL
        GROUP BY Record_Date
        ORDER BY Record_Date ASC
        LIMIT 7
    """, (user_id, user_id, user_id, user_id))
    chart_rows = cursor.fetchall()
    
    chart_labels = [row['activity_date'] for row in chart_rows] if chart_rows else ['Today']
    chart_data = [float(row['daily_total']) for row in chart_rows] if chart_rows else [0]

    # 5. Fetch Recent Activity Records
    cursor.execute("""
        SELECT 'Electricity' as type, Appliance_Name as detail, CONCAT(Units_Consumed, ' kWh') as value, Record_Date FROM electricity_usage WHERE User_ID = %s
        UNION ALL
        SELECT 'Water' as type, Activity_Type as detail, CONCAT(Water_Consumed, ' L') as value, Record_Date FROM water_usage WHERE User_ID = %s
        UNION ALL
        SELECT 'Carbon' as type, Transport_Type as detail, CONCAT(Total_Emission, ' kg') as value, Record_Date FROM carbon_record WHERE User_ID = %s
        UNION ALL
        SELECT 'Waste' as type, Waste_Type as detail, CONCAT(Quantity, ' kg') as value, Record_Date FROM waste_record WHERE User_ID = %s
        ORDER BY Record_Date DESC
    """, (user_id, user_id, user_id, user_id))
    recent_records = cursor.fetchall()
    cursor.close()
    conn.close()

    user_name = session.get('user_name', 'Eco User')
    name_parts = user_name.split()
    user_initials = "".join([p[0].upper() for p in name_parts[:2]]) if name_parts else "EU"

    return render_template(
        'dashboard.html',
        total_carbon=total_carbon,
        total_electricity=total_electricity,
        total_water=total_water,
        total_waste=total_waste,
        eco_score=eco_score,
        avg_7day_score=avg_7day_score,
        saved_weekly_scores=saved_weekly_scores,
        saved_monthly_scores=saved_monthly_scores,
        chart_labels=chart_labels,
        chart_data=chart_data,
        recent_records=recent_records,
        user_name=user_name,
        user_initials=user_initials
    )


@app.route('/carbon')
def carbon():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    user_id = session['user_id']
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    cursor.execute("SELECT IFNULL(SUM(Total_Emission), 0) AS total FROM carbon_record WHERE User_ID = %s AND Record_Date = CURDATE()", (user_id,))
    today_total = round(float(cursor.fetchone()['total']), 1)
    
    cursor.execute("SELECT IFNULL(SUM(Total_Emission), 0) AS total FROM carbon_record WHERE User_ID = %s", (user_id,))
    total_all = round(float(cursor.fetchone()['total']), 1)
    
    cursor.close()
    conn.close()

    user_name = session.get('user_name', 'Eco User')
    name_parts = user_name.split()
    user_initials = "".join([p[0].upper() for p in name_parts[:2]]) if name_parts else "EU"

    return render_template('carbon.html', today_total=today_total, total_all=total_all, user_name=user_name, user_initials=user_initials)


@app.route('/electricity')
def electricity():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    user_id = session['user_id']
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    cursor.execute("SELECT IFNULL(SUM(Units_Consumed), 0) AS total FROM electricity_usage WHERE User_ID = %s AND Record_Date = CURDATE()", (user_id,))
    today_total = round(float(cursor.fetchone()['total']), 1)
    
    cursor.execute("SELECT IFNULL(SUM(Units_Consumed), 0) AS total FROM electricity_usage WHERE User_ID = %s", (user_id,))
    total_all = round(float(cursor.fetchone()['total']), 1)
    
    cursor.close()
    conn.close()

    user_name = session.get('user_name', 'Eco User')
    name_parts = user_name.split()
    user_initials = "".join([p[0].upper() for p in name_parts[:2]]) if name_parts else "EU"

    return render_template('electricity.html', today_total=today_total, total_all=total_all, user_name=user_name, user_initials=user_initials)


@app.route('/water')
def water():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    user_id = session['user_id']
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    cursor.execute("SELECT IFNULL(SUM(Water_Consumed), 0) AS total FROM water_usage WHERE User_ID = %s AND Record_Date = CURDATE()", (user_id,))
    today_total = round(float(cursor.fetchone()['total']), 1)
    
    cursor.execute("SELECT IFNULL(SUM(Water_Consumed), 0) AS total FROM water_usage WHERE User_ID = %s", (user_id,))
    total_all = round(float(cursor.fetchone()['total']), 1)
    
    cursor.close()
    conn.close()

    user_name = session.get('user_name', 'Eco User')
    name_parts = user_name.split()
    user_initials = "".join([p[0].upper() for p in name_parts[:2]]) if name_parts else "EU"

    return render_template('water.html', today_total=today_total, total_all=total_all, user_name=user_name, user_initials=user_initials)


@app.route('/waste')
def waste():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    user_id = session['user_id']
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    cursor.execute("SELECT IFNULL(SUM(Quantity), 0) AS total FROM waste_record WHERE User_ID = %s AND Record_Date = CURDATE()", (user_id,))
    today_total = round(float(cursor.fetchone()['total']), 1)
    
    cursor.execute("SELECT IFNULL(SUM(Quantity), 0) AS total FROM waste_record WHERE User_ID = %s", (user_id,))
    total_all = round(float(cursor.fetchone()['total']), 1)
    
    cursor.close()
    conn.close()

    user_name = session.get('user_name', 'Eco User')
    name_parts = user_name.split()
    user_initials = "".join([p[0].upper() for p in name_parts[:2]]) if name_parts else "EU"

    return render_template('waste.html', today_total=today_total, total_all=total_all, user_name=user_name, user_initials=user_initials)


# --- AUTHENTICATION ROUTES ---

@app.route('/login', methods=['GET', 'POST'])
def login():
    error_message = None
    if request.method == 'POST':
        email = request.form.get('email')         
        password = request.form.get('password')   
        
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE Email = %s AND Password = %s", (email, password))
        user = cursor.fetchone()
        cursor.close()
        conn.close()
        
        if user:
            session['user_id'] = user['User_ID']
            session['user_name'] = user['Name']
            session['role'] = user.get('Role', 'User') # Save role in session
            
            # Redirect based on role
            if session['role'] in ['Admin', 'Developer']:
                return redirect(url_for('admin_dashboard'))
            else:
                return redirect(url_for('dashboard'))
        else:
            error_message = "Invalid email or password. Please try again."
            
    return render_template('login.html', error=error_message)


@app.route('/admin_dashboard')
def admin_dashboard():
    # Security check: Ensure user is logged in and is an Admin or Developer
    if 'user_id' not in session or session.get('role') not in ['Admin', 'Developer']:
        return redirect(url_for('login'))
        
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    cursor.execute("SELECT User_ID, Name, Email, Phone, Location, Role FROM users")
    all_users = cursor.fetchall()
    
    cursor.execute("SELECT COUNT(*) AS count FROM users")
    total_users_count = cursor.fetchone()['count']
    
    cursor.execute("SELECT COUNT(*) AS count FROM carbon_record")
    total_carbon_records = cursor.fetchone()['count']

    cursor.execute("SELECT COUNT(*) AS count FROM electricity_usage")
    total_elec_records = cursor.fetchone()['count']
    
    cursor.execute("SELECT COUNT(*) AS count FROM water_usage")
    total_water_records = cursor.fetchone()['count']

    cursor.execute("SELECT COUNT(*) AS count FROM waste_record")
    total_waste_records = cursor.fetchone()['count']
    
    cursor.close()
    conn.close()

    user_name = session.get('user_name', 'Administrator')
    user_initials = "AD"

    return render_template(
        'admin_dashboard.html',
        user_name=user_name,
        user_initials=user_initials,
        all_users=all_users,
        total_users_count=total_users_count,
        total_carbon_records=total_carbon_records,
        total_elec_records=total_elec_records,
        total_water_records=total_water_records,
        total_waste_records=total_waste_records
    )


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name')           
        email = request.form.get('email')         
        phone = request.form.get('phone')         
        location = request.form.get('location')   
        password = request.form.get('password')   
        
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(
                "INSERT INTO users (Name, Phone, Email, Password, Location) VALUES (%s, %s, %s, %s, %s)",
                (name, phone, email, password, location)
            )
            conn.commit()
        except Exception as e:
            print(f"Error registering user: {e}")
        finally:
            cursor.close()
            conn.close()
        
        return redirect(url_for('login'))
        
    return render_template('register.html')


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))


# --- TRACKING FORM SUBMISSION & CALCULATION ROUTES ---

@app.route('/add_carbon', methods=['POST'])
def add_carbon():
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    if request.method == 'POST':
        user_id = session['user_id']
        transport_type = request.form.get('transport_type')
        distance_travelled = float(request.form.get('distance_travelled') or 0)
        
        electricity_units = float(request.form.get('electricity_units') or 0)
        lpg_usage = float(request.form.get('lpg_usage') or 0)
        food_type = request.form.get('food_type')
        record_date = request.form.get('record_date')
        
        transport_factors = {'car': 0.21, 'bike': 0.08, 'bus': 0.05, 'train': 0.04, 'flight': 0.25, 'motorcycle': 0.12, 'walking': 0.0, 'other': 0.20}
        t_factor = transport_factors.get(str(transport_type).lower(), 0.20)
        transport_emission = distance_travelled * t_factor
        
        electricity_emission = electricity_units * 0.85
        lpg_emission = lpg_usage * 2.98
        
        food_factors = {'non-vegetarian': 3.3, 'vegetarian': 1.5, 'vegan': 1.0, 'mixed': 2.2}
        f_factor = food_factors.get(str(food_type).lower(), 2.0)
        food_emission = f_factor * 1.0
        
        total_emission = transport_emission + electricity_emission + lpg_emission + food_emission
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            """INSERT INTO carbon_record 
            (User_ID, Transport_Type, Distance_Traveled, Transport_Emission, Electricity_Units, Electricity_Emission, LPG_Usage, LPG_Emission, Food_Type, Food_Emission, Total_Emission, Record_Date) 
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
            (user_id, transport_type, distance_travelled, transport_emission, electricity_units, electricity_emission, lpg_usage, lpg_emission, food_type, food_emission, total_emission, record_date)
        )
        conn.commit()
        cursor.close()
        conn.close()
        
        return redirect(url_for('dashboard'))


@app.route('/add_electricity', methods=['POST'])
def add_electricity():
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    if request.method == 'POST':
        user_id = session['user_id']
        appliance_name = request.form.get('appliance_name')
        usage_hours = float(request.form.get('usage_hours') or 0)
        units_consumed = float(request.form.get('units_consumed') or 0)
        record_date = request.form.get('record_date')
        
        carbon_emission = units_consumed * 0.85
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            """INSERT INTO electricity_usage 
            (User_ID, Appliance_Name, Usage_Hours, Units_Consumed, Carbon_Emission, Record_Date) 
            VALUES (%s, %s, %s, %s, %s, %s)""",
            (user_id, appliance_name, usage_hours, units_consumed, carbon_emission, record_date)
        )
        conn.commit()
        cursor.close()
        conn.close()
        
        return redirect(url_for('dashboard'))


@app.route('/add_water', methods=['POST'])
def add_water():
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    if request.method == 'POST':
        user_id = session['user_id']
        activity_type = request.form.get('activity_type')
        water_consumed = float(request.form.get('water_consumed') or 0)
        record_date = request.form.get('record_date')
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            """INSERT INTO water_usage 
            (User_ID, Activity_Type, Water_Consumed, Record_Date) 
            VALUES (%s, %s, %s, %s)""",
            (user_id, activity_type, water_consumed, record_date)
        )
        conn.commit()
        cursor.close()
        conn.close()
        
        return redirect(url_for('dashboard'))


@app.route('/add_waste', methods=['POST'])
def add_waste():
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    if request.method == 'POST':
        user_id = session['user_id']
        waste_type = request.form.get('waste_type')
        quantity = float(request.form.get('quantity') or 0)
        recycled_quantity = float(request.form.get('recycled_quantity') or 0)
        disposal_method = request.form.get('disposal_method')
        record_date = request.form.get('record_date')
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            """INSERT INTO waste_record 
            (User_ID, Waste_Type, Quantity, Recycled_Quantity, Disposal_Method, Record_Date) 
            VALUES (%s, %s, %s, %s, %s, %s)""",
            (user_id, waste_type, quantity, recycled_quantity, disposal_method, record_date)
        )
        conn.commit()
        cursor.close()
        conn.close()
        
        return redirect(url_for('dashboard'))


if __name__ == '__main__':
    app.run(debug=True)